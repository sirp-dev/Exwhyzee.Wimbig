﻿CREATE PROCEDURE [dbo].[spWalletUpdate]
	@Id bigint not null,
	@userId nvarchar(100) not null,
	@balance decimal not null,
	@dateUpdated datetime not null

AS
Begin
	  UPDATE[dbo].[Wallets]  SET 
	  [UserId] = @userId,
	  [Balance] = @balance,
	  [DateUpdated] = @dateUpdated
WHERE Id = @Id
End