﻿CREATE PROCEDURE [dbo].[spWalletReadByUserId]
	@userId nvarchar(100) not null
AS
Begin
	SELECT * from [dbo].[Wallets] Where [UserId] = @userId
	
End