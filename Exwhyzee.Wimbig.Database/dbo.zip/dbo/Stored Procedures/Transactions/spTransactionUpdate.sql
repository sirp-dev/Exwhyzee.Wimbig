﻿CREATE PROCEDURE [dbo].[spTransactionUpdate]
	@Id bigint not null,
	@walletId bigint not null,
	@userId nvarchar(100) not null,
	@amount decimal not null,
	@transactionType int not null,
	@dateOfTransaction datetime not null

AS
Begin
	  UPDATE[dbo].[Transactions]  SET 
	  [WalletdId]  = @walletId,
	  [UserId] = @userId,
	  [Amount] = @amount,
	  [TransactionType] = @transactionType,
	  [DateOfTransaction] = @dateOfTransaction
WHERE Id = @Id
End