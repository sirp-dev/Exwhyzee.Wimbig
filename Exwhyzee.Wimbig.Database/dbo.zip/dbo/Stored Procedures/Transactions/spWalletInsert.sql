﻿CREATE PROCEDURE [dbo].[spWalletInsert]
	@userId nvarchar(100) not null,
	@balance decimal not null,
	@dateUpdated datetime not null

AS
Begin
	  INSERT INTO[dbo].[Wallets] ([UserId],[Balance],[DateUpdated]) 
      output inserted.Id 
      VALUES (@userId, @balance,@dateUpdated) 
End
