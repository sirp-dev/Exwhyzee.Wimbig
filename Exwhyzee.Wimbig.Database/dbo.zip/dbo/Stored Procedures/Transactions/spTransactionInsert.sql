﻿CREATE PROCEDURE [dbo].[spTransactionInsert]
	@walletId bigint not null,
	@userId nvarchar(100) not null,
	@amount decimal not null,
	@transactionType int not null,
	@dateOfTransaction datetime not null

AS
Begin
	  INSERT INTO[dbo].[Transactions] ([WalletdId],[UserId],[Amount],[TransactionType],[DateOfTransaction]) 
      output inserted.Id 
      VALUES (@walletId,@userId,@amount,@transactionType,@dateOfTransaction) 
End