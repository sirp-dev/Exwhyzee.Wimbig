﻿-- Get all images

CREATE PROCEDURE [dbo].[spImageFileGetAll]	
	@extension nvarchar(10),

	@dateStart datetime null,
	@dateStop datetime null,

	@startIndex int = null,
	@count int = 2147483647
AS
BEGIN 
	SELECT * From [dbo].[Imagefile] WHere 1=1 

	AND (@extension IS NULL or [ImageExtension] = @extension)
	AND(@dateStart IS NULL OR [DateCreated] >= @dateStart)
	AND (@dateStop IS NULL OR [DateCreated] <= @dateStop)

	ORDER BY [DateCreated] DESC
	OFFSET @startIndex ROWS
	FETCH NEXT @count ROWS ONLY

END