﻿-- Create a new image entity

CREATE PROCEDURE [dbo].[spImageInsert]
	@url nvarchar(299) = 0,
	@dateCreated dateTime,
	@imageExtension nvarchar(10),
	@status int null
AS
BEGIN

	INSERT INTO [dbo].[ImageFile] ([Url],[ImageExtension],[DateCreated],[Status])
	output inserted.Id

	VALUES(@url, @imageExtension, @dateCreated, @status)
	
	END
