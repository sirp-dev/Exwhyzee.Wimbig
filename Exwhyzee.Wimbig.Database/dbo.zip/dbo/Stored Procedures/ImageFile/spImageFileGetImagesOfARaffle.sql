﻿-- Get all Images For a Particular Raffle

CREATE PROCEDURE [dbo].[spImageFileGetImagesOfARaffle]
	
	@mapImageToRaffleId bigint = null,
	@dateStart datetime null,
	@dateStop datetime null,

	@startIndex int = null,
	@count int = 2147483647
AS
BEGIN
SELECT img.[Id], img.[ImageExtension], [img].[Url], [img].DateCreated From [dbo].[Imagefile] as img,[dbo].[MapImagesToRaffle]  as mappedImage WHere 1=1 

	AND (@mapImageToRaffleId IS NULL OR mappedImage.[ImageId] = @mapImageToRaffleId)
	AND (@dateStart IS NULL OR img.DateCreated >= @dateStart)
	AND (@dateStop IS NULL OR img.[DateCreated] <= @dateStop)

	ORDER BY img.[DateCreated] DESC
	OFFSET @startIndex ROWS
	FETCH NEXT @count ROWS ONLY

END
