﻿--Create Category Entity

CREATE PROCEDURE [dbo].[spCategoryInsert]
	@categoryId int=0,
	@categoryName nvarchar(250) ,
	@dateCreated datetime,
	@decription nvarchar(Max),
	@sectionId int,
	@entityStatus int
AS
BEGIN
	INSERT INTO [dbo].[Category] ([CategoryId],[Name],[DateCreated],[Description],[SectionId],[EntityStatus])
	output inserted.CategoryId

	VALUES (@categoryId,@categoryName,@dateCreated,@decription,@sectionId,@entityStatus)
END
