﻿-- Get Category

CREATE PROCEDURE [dbo].[spCategoryGetAll]
	@status int = null,
	@dateStart datetime = null,
	@dateEnd datetime = null,
	
	@startIndex int = 0,
	@count int = 2147483647,
	@search nvarchar(250)= null

	
AS
BEGIN
	SELECT * FROM [dbo].[Category] WHERE 1=1
	ANd ([EntityStatus] != 2)
	AND(@dateStart = null OR [DateCreated] >= @dateStart)
	AND (@dateEnd = null OR [DateCreated] <= @dateEnd)
	AND(@search = null OR [Name] like @search OR [Description] like @search)

	ORDER BY [Name] ASC
	OFFSET @startIndex ROWS
	FETCH NEXT @count ROWS ONLY

END
