﻿--Get Mapped Iamge by Identifier

CREATE PROCEDURE [dbo].[spMapImageToRaffleGetById]
	@id bigint = 0
AS
BEGIN
	SELECT * from [dbo].[MapImagesToRaffle] Where [Id] = @id

END
