﻿---Get All Mapped Images By RaffleId

CREATE PROCEDURE [dbo].[spMapImageToRaffleGetByRaffleId]
	@raffleId bigint = 0
	
AS
BEGIN
	SELECT * From [dbo].[MapImagesToRaffle] Where [RaffleId]=@raffleId
END
