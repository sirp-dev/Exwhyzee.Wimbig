﻿--- Get MappedImageTo Raffle by ImageId

CREATE PROCEDURE [dbo].[spMapImageToRaffleGetByImageId]
	@imageId bigint = 0
AS
BEGIN
	SELECT * from [dbo].[MapImagesToRaffle] Where [ImageId]= @imageId

END
