﻿--Update Entity

CREATE PROCEDURE [dbo].[spMapImageToRaffleUpdate]
	@imageId bigint = 0,
	@raffleId bigint = 0
AS
BEGIN

UPDATE[dbo].[MapImagesToRaffle] SET [ImageId] =@imageId ,[RaffleId] = @raffleId

END
