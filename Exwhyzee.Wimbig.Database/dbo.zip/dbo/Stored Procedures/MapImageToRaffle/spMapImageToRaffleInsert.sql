﻿-- CReate MApping--

CREATE PROCEDURE [dbo].[spMapImageToRaffleInsert]

	@raffleId bigint,
	@imageId bigint,
	@dateCreated datetime null
AS
BEGIN
	INSERT INTO [dbo].[MapImagesToRaffle] ([ImageId],[RaffleId],[DateCreated])
	output inserted.Id
	VALUES(@raffleId,@imageId,@dateCreated)

END
