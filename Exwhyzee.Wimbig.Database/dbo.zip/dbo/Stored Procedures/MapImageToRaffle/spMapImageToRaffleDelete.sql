﻿-- Delete MapImageToRaffle

CREATE PROCEDURE [dbo].[spMapImageToRaffleDelete]
	@id bigint = 0
AS
BEGIN
	DELETE  MapImagesToRaffle WHERE  Id = @id
	
END