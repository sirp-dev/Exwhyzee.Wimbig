﻿CREATE PROCEDURE [dbo].[spMapImageToRaffleGetAll]
	@startIndex int = null,
	@count int = null

AS
BEGIN 

	SELECT * From [dbo].[MapImagesToRaffle]

	ORDER BY Id DESC
	OFFSET @startIndex ROWS
	FETCH NEXT @count ROWS ONLY	
END
