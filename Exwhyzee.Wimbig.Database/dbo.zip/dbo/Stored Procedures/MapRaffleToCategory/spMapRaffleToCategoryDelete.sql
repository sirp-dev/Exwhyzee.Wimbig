﻿-- Delete MapRaffleToCategory

CREATE PROCEDURE [dbo].[spMapRaffleToCategoryDelete]
	@id bigint = 0
AS
BEGIN

	DELETE [dbo].[MapImagesToRaffle] WHERE [Id]=@id
END
