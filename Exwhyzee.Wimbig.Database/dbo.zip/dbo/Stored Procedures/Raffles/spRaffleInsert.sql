﻿-- Create a new Raffle

CREATE PROCEDURE [dbo].[spRaffleInsert]
	@name nvarchar(250),
	@description nvarchar(Max),
	@hostedBy nvarchar(250),
	@numberOfTickets int,
	@pricePerTicket decimal,
	@deliveryType int,
	@startDate dateTime,
	@endDate dateTime,
	@status int,
	@dateCreated datetime

AS
Begin
	  INSERT INTO[dbo].[Raffle] (
	  [Name],[Description],[HostedBy],
	  [NumberOfTickets],[PricePerTicket],
	  [DeliveryType],[StartDate],
	  [EndDate],[Status],[DateCreated]) 
                                    
									output inserted.Id 
                                    VALUES 
	(@name, @description, @hostedBy,
	@numberOfTickets, @pricePerTicket,
	@deliveryType, @startDate,
	@endDate, @status, @dateCreated) 
End
