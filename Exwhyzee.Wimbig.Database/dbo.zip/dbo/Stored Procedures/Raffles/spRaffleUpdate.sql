﻿CREATE PROCEDURE [dbo].[spRaffleUpdate]
	@id bigint,
	@name nvarchar(250),
	@description nvarchar(Max),
	@hostedBy nvarchar(250),
	@numberOfTickets int,
	@pricePerTicket decimal ,
	@deliveryType int,
	@startDate dateTime ,
	@endDate dateTime ,
	@status int,
	@dateCreated datetime,
	
AS
BEGIN

	UPDATE[dbo].[Raffle] SET [Name] =@name ,
	[Description] = @description,
	[HostedBy] = @hostedBy,
	[NumberOfTickets] = @numberOfTickets,
	[PricePerTicket] = @pricePerTicket,
	[DeliveryType] = @deliveryType,
	[StartDate] = @startDate,
	[EndDate] = @endDate,
	[Status] = @status,
	[DateCreated] = @dateCreated
                 
Where Id = @id
End
