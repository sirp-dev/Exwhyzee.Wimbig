﻿CREATE PROCEDURE [dbo].[spTicketInsert]
	@userId nvarchar(250),
	@raffleId bigint,
	@ticketNumber int,
	@datePurchased datetime

AS
Begin
	  INSERT INTO[dbo].[Ticket] (
	  [UserId],[RaffleId],[TicketNumber],[DatePurchased]) 
                                    
		output inserted.Id 
        VALUES 
	(@userId, @raffleId, @ticketNumber,
	@datePurchased) 
End