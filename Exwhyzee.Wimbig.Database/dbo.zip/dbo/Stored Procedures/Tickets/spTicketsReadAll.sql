﻿CREATE PROCEDURE [dbo].[spTicketsReadAll]
@status int = null,
@dateStart datetime = null,
@dateEnd datetime = null,
@startIndex int = 0,
@count int = 2147483647,
@searchString nvarchar(200) = null
	
AS

	DECLARE @FilteredCount INT = 0
	DECLARE @TotalCount INT = 0

	SELECT [Ticket].Id AS Id, [Ticket].UserId,[Ticket].RaffleId,Ticket.TicketNumber,AspNetUsers.Email,AspNetUsers.PhoneNumber,
	CONCAT(AspNetUsers.FirstName, AspNetUsers.LastName,AspNetUsers.OtherNames) AS FullName, Ticket.DatePurchased,
	[AspNetUsers].UserName AS Username INTO #TempTableFiltered FROM [Ticket]  
	LEFT JOIN [AspNetUsers] ON [Ticket].UserId = [AspNetUsers].Id


	WHERE 1 = 1 
	AND (@dateStart Is NULL OR [DatePurchased] >= @dateStart)
	AND (@dateEnd IS NULL OR [DatePurchased] <= @dateEnd)
	--AND (@status IS NULL OR [Status] = @status)
	AND (@searchString IS NULL OR [TicketNumber] Like @searchString)
	
	--set table total
	SELECT @TotalCount = ISNULL(COUNT(Id),0) FROM [Ticket] WITH(NOLOCK) 

	--set filtered count
	SELECT @FilteredCount = ISNULL(COUNT(Id),0) FROM #TempTableFiltered

	--Select table result
	SELECT * FROM #TempTableFiltered
	ORDER BY Ticket.DatePurchased DESC
	OFFSET @startIndex ROWS 
	FETCH NEXT @count ROWS ONLY

	--SELECT Summary Result
	SELECT @FilteredCount AS FilteredCount, @TotalCount AS TotalCount

	RETURN