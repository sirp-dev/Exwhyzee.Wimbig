﻿-- Get all Section with pagination and search params

CREATE PROCEDURE [dbo].[spSectionGetAll]
	@status int = null,
	@dateStart datetime = null,
	@dateEnd datetime = null,
	@search nvarchar(250)= null,

	@startIndex int = 0,
	@count int = 2147483647
AS
BEGIN
	SELECT * FROM [dbo].[Section] WHERE 1=1
	AND(@dateStart = null OR [DateCreated] >= @dateStart)
	AND (@dateEnd = null OR [DateCreated] <= @dateEnd)
	AND(@search = null OR [Name] like @search OR [Description] like @search)

	ORDER BY [Name] ASC
	OFFSET @startIndex ROWS
	FETCH NEXT @count ROWS ONLY
END
