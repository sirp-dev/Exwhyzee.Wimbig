﻿CREATE TABLE [dbo].[Raffle]
(
	[Id] BIGINT NOT NULL PRIMARY KEY Identity(1,1),
	[Name] nvarchar(250) NOT NULL,
	[Description] nvarchar(Max) null,
	[NumberOfTickets] int not null,
	[PricePerTicket] decimal not null,
	[HostedBy] NVARCHAR(250) not null,
	[DeliveryType] int,
	[StartDate] datetime null,
	[EndDate] datetime null,
	[Status] int,
	[DateCreated] datetime not null, 

)
