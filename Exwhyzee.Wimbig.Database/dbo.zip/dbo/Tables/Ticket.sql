﻿CREATE TABLE [dbo].[Ticket]
(
	[Id] BIGINT NOT NULL PRIMARY KEY IDENTITY(1,1),
	[UserId] nvarchar(100) not null,
	[RaffleId] bigint not null,
	[TicketNumber] int not null,
	[DatePurchased] datetime not null,
	
)